

set -ex



ls -alh ${PREFIX}/fonts/
exit 0
