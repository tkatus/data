print("import: 'imagesize'")
import imagesize

