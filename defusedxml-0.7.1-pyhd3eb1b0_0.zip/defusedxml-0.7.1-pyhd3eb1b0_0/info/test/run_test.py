print("import: 'defusedxml'")
import defusedxml

