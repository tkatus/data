

set -ex



pip check
exit 0
